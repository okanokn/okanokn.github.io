#include <Scrobo.h>

Scrobo robo = Scrobo();

void setup()
{
  Serial.begin(38400); // Open serial port at 38400 [baud]
  Serial.println("Connected");
}

void loop()
{
  // Read analog inputs
  int ball_left = analogRead(0);   // A0
  int ball_center = analogRead(1); // A1
  int ball_right = analogRead(2);  // A2
  int range = analogRead(3);       // A3
  int floor_left = analogRead(6);  // A6
  int floor_right = analogRead(7); // A7

  // Serial outputs
  Serial.print(ball_left);
  Serial.print(",");
  Serial.print(ball_center);
  Serial.print(",");
  Serial.print(ball_right);
  Serial.print(",");
  Serial.print(range);
  Serial.print(",");
  Serial.print(floor_left);
  Serial.print(",");
  Serial.print(floor_right);
  Serial.println();

  // Wait 1 sec
  delay(1000);
}
