#include <Scrobo.h>

Scrobo robo = Scrobo();

void setup() {
  Serial.begin(38400);  // Open serial port at 38400 [baud]
  Serial.println("Connected");
}

void loop() {
  delay(2000);

  // Move forward
  robo.setSpeedM1(100);
  robo.setSpeedM2(100);
  delay(1500);

  // Stop
  robo.setSpeedM1(0);
  robo.setSpeedM2(0);
  delay(1000);

  // Move backward
  robo.setSpeedM1(-100);
  robo.setSpeedM2(-100);
  delay(1500);

  // Stop
  robo.setSpeedM1(0);
  robo.setSpeedM2(0);
  delay(1000);

  // Zigzag
  for (int i = 0; i < 4; i++) {
    robo.setSpeedM1(100);
    robo.setSpeedM2(30);
    delay(500);
    robo.setSpeedM1(30);
    robo.setSpeedM2(100);
    delay(500);
  }
  robo.setSpeedM1(0);
  robo.setSpeedM2(0);
  delay(1000);

  // Turn left
  robo.setSpeedM1(-100);
  robo.setSpeedM2(100);
  delay(1500);

  // Stop
  robo.setSpeedM1(0);
  robo.setSpeedM2(0);
  delay(1000);

  // Turn right
  robo.setSpeedM1(100);
  robo.setSpeedM2(-100);
  delay(1500);

  // Stop
  robo.setSpeedM1(0);
  robo.setSpeedM2(0);
  delay(1000);

  // Dribbling
  robo.setSpeedM3(100);  // forward
  delay(2000);
  robo.setSpeedM3(0);  // stop
  delay(1000);
  robo.setSpeedM3(-100);  // reverse
  delay(2000);
  robo.setSpeedM3(0);  // stop
  delay(1000);

  // Stop and wait
  robo.setSpeedM3(0);
  while (1) {}
}
